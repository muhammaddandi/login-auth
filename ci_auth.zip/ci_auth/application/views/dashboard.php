<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel=" stylesheet" href="<?= base_url() ?>assets/css/bootstrap.min.css">

    <style>
        .color {
            color: blueviolet;
        }

        hr {
            width: 250px;
            border-top: 3px solid blue;
        }

        .about {
            margin-bottom: 100px;
        }

        a {
            text-decoration: none !important;
        }

        .card:hover {
            background-color: #ddd;
        }
    </style>
</head>

<body><br><br>
    

    <nav class="navbar navbar-expand-lg navbar-toggler navbar-dark  fixed-top nav" style="background-color:darkviolet">
        <div class="container">
            <a class="navbar-brand" href="#home">Welcome, Its me Muhammad Dandi</a>
            <button aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"
                class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button"><span
                    class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" style="padding: 9px;" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Who am i <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#skills">My Skills</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#experience">experience</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Get In Touch</a>
                    </li>
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="#">sign out</a> -->
                        <a href="<?= site_url('Auth/logout') ?>" class="btn btn-default btn-flat">Sign out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>



    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-8"><br><br><br>
                <h2 style="text-align: center;">My Name is muhammad dandi </h2>
                <h5 style="text-align: center;">full stack developer at sehati jaya pharma</h5>
                <h6 style="text-align: center;">I'm a hard
                    worker, responsible, work in target, and I am also an easy going person.
                </h6>
            </div>
            <div class="col-12 col-md-4">
                
                <img src="<?= base_url() ?>/assets/img/fotoku.jpg" class="rounded-circle" width="300">
            </div>
        </div>
    </div>
    <br>
    <div class="container">
        <div class="row">
            <div class="col text-center">
                <h2>About Me</h2>
                <hr>
            </div>

        </div>
        <div class="row">
            <div class="col text-justify">
                <p>
                    saya adalah lulusan D3 manajemen informatika di BINA SARANA INFORMATIKA thn 2006
                </p>
            </div>
            <div class="col text-justify">
                <p>
                <!-- Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit iusto veniam repellendus
                    perspiciatis
                    id natus. Molestias accusantium itaque mollitia velit aliquam ab officiis qui aliquid rerum
                    dicta,
                    aut, eligendi tempore. -->
                    </p>
            </div>
        </div>
    </div>
    <br><br>
    <section class="skills bg-light" id="skills">
        <div class="container">
            <!-- Baris Judul -->
            <div class="row">
                <div class="col text-center">
                    <h3 class="pt-3">Skills programing</h3>
                    <hr>
                </div>
            </div>
            <h3>HTML</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="0" style="width: 90%"
                    ria-valuemin="90" aria-valuemax="100">
                </div>
            </div><br>
            <h3>CSS</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 90%" aria-valuenow="25"
                    aria-valuemin="0" aria-valuemax="100"></div>
            </div><br>
            <h3>javascript</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="50"
                    aria-valuemin="0" aria-valuemax="100"></div>
            </div><br>
            <h3>jquery</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="90"
                    aria-valuemin="0" aria-valuemax="100">
                </div><br>
            </div><br>
            <h3>php</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>
            <h3>bootstrap</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 90%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>
            <h3>codeigniter</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 90%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>
            <h3>laravel</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 60%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>
            <h3>cms</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 90%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>
            <h3>mariadb</h3>
            <div class="progress">
                <div class="progress-bar bg-primary" role="progressbar" style="width: 90%" aria-valuenow="75"
                    aria-valuemin="0" aria-valuemax="100"></div><br>
            </div><br>




            <br>
        </div>
    </section><br><br>
    <section class="experience bg-light" id="experience">
        <div class="row">
            <div class="container">
                <div class="col text-center">
                    <h3 class="pt-3">experience</h3>
                    <hr>
                </div>

                <table class="table table-sm table-sm">
                    <thead>
                        <tr>
                            <th scope="col">no</th>
                            <th scope="col">company</th>
                            <th scope="col">position</th>
                            <th scope="col">tahun</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>RS CIPTO MANGUNKUSUMO</td>
                            <td>IT Support</td>
                            <td>2007-2010</td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>UNIVERSITAS TELKOM</td>
                            <td>Laboran</td>
                            <td>2010-2012</td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>RS CIKUNIR</td>
                            <td>IT </td>
                            <td>2014-2019</td>
                        </tr>
                        <tr>
                            <th scope="row">4</th>
                            <td>PT SEHATI JAYA PHARMA</td>
                            <td>system developer</td>
                            <td>2020-now</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            </class>

    </section>







    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mt-5">
                    <h1>Let's Get In Touch!</h1>
                    <hr class="my-4">
                    <p>Ready to start your next project with us? That's great! Give us a call or send us an email and we
                        will get back to you as soon as possible!</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 ml-auto text-center mb-5">
                    <p>0822 9831 3579 </p>
                </div>
                <div class="col-lg-4 mr-auto text-center">
                    <p>
                        <a href="mailto:dandi.telkom@gmail.com">dandi.telkom@gmail.com</a>
                    </p>
                </div>
            </div>
        </div>
    </section>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="/js/bootstrap.js"></script>
</body>
<footer class="text-white mt-5" style="background-color: blueviolet;">
    <div class="container">
        <div class="row">
            <div class="col text-center pt-3">
                <p>Copyright &copy; dandi 2020.</p>
            </div>
        </div>
    </div>
</footer><!-- Akhir Footer -->

</html>