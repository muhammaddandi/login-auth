Project CI_AUTH by https://ilmucoding.com

Project membuat fitur login, register dan logout menggunakan framework codeigniter 3.1.11. 

Silahkan clone / download projectnya dan jangan lupa untuk klik start. 

Terima kasih.

Link tutorial: https://ilmucoding.com/codeigniter-login-register-logout
